# main code to run everything multiple times
def main():
  import random
  name =input("Hi, What is your name: ")
  print(f"OK, {name} lets start the game!!") 
  HANGMAN = (
"""
-----
|   |
|   0
| /-+-\ 
|   | 
|   | 
|  | | 
|  | | 
|
--------
""")

  print(HANGMAN)
  # random words NBA
  wordlist = ["lakers", "warriors", "spurs", "raptors","celtics","cavaliers","rockets","thunder", "knicks","bulls", "philadelphia", "heat", "mavericks", "nuggets", "suns", "bucks", "clippers", "pelicans", "timberwolves", "pistons", "jazz", "hawks", "wizards", "hornets", "trailblazers", "kings", "nets", "pacers", "grizzles","magic"]
#randomize list and 
  random.shuffle(wordlist) 
  answers = list(wordlist[0])

  show = []
  show.extend(answers)

  for i in range(len(show)):
    show[i] = "_"

  print(" ".join(show))
  print()

  # global variables
  counter = 0
  number = 0
  guessed = [] 
  tries = 0
  guess = None
  play_again =True


  while counter < len(answers):
    print("**Hint: Name of NBA Basketball team **")
    guess = input("Guess a letter: ")
    guess = guess.lower()
    print(f"letters correct:{counter}")
    number = number + 1
    tries = tries + 1
    counter = counter
    # ways to leave game early
    if guess == "quit" or guess == "stop": 
      break
    # if your guess is wrong
    elif guess not in answers: 
      print("Sorry, wrong letter try again")
    #if you already guessed the letter
    if guess in guessed: 
      print(f"you already guessed {guess}")
    # words you already guessed
    guessed.append(guess)
    print(f"word bank: {guessed}")
    # cycle though to see if guessed etter is correct
    for i in range(len(answers)):
      if answers[i] == guess: #and (guess not in guessed):
        show[i] = guess 
        counter = counter + 1    
    
    print(" ".join(show))
    print() 

  print(f"you guessed the word in {tries} tries!")

  play_again= input("\nWould you like to play game?").lower()
  if play_again == "yes" or play_again == "y":
    main()
  else:
    print("Thanks for playing you winner!! (;")
    exit()

#where the code starts
main()




